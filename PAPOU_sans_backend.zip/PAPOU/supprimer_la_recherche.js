function supression(){
    localStorage.setItem('specialite', null);  //clé='specialité' ; valeur = variable specialite
    localStorage.setItem('nom_medecin', null);
    localStorage.setItem('adresse', null);
    localStorage.setItem('code_postal', null);
    localStorage.setItem('ville', null);
    localStorage.setItem('pays', null);
    localStorage.setItem('perimetre', null);
    localStorage.setItem('jours', null);
    localStorage.setItem('horaires', null);
}
