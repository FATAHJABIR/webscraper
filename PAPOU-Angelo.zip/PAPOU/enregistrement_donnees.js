
document.getElementById("data").addEventListener("submit1", test1);
document.getElementById("data").addEventListener("submit2", test2);

var specialite ;
var nom_medecin ; 
var adresse  ; 
var code_postal ;
var ville ;
var pays ; 
var perimetre ;
var jours = " ";
var horaires = " ";
monStockage = localStorage;
var semaine = ['lundi', ' mardi', ' mercredi', ' jeudi', ' vendredi', ' samedi', ' dimanche'];
var creneaux = ['; 8h-10h', ',10h-12h',',12h-14h',',14h-16h',',16h-18h',',18h-20h']



function test1 (form){
    specialite = document.getElementById("specialite").value;
    nom_medecin = document.getElementById("nom_medic").value;
    adresse = document.getElementById("adresse").value;
    code_postal = document.getElementById("code-postal").value;
    ville = document.getElementById("ville").value;
    pays = document.getElementById("pays").value;
    perimetre = document.getElementById("périmètre").value;
    alert(specialite);
    localStorage.setItem('specialite', specialite);
    localStorage.setItem('nom_medecin', nom_medecin);
    localStorage.setItem('adresse', adresse);
    localStorage.setItem('code_postal', code_postal);
    localStorage.setItem('ville', ville);
    localStorage.setItem('pays', pays);
    localStorage.setItem('perimetre', perimetre);
    var check1 = [new Boolean(document.getElementById("lun").checked),new Boolean(document.getElementById("mar").checked),new Boolean(document.getElementById("mer").checked),new Boolean(document.getElementById("jeu").checked),new Boolean(document.getElementById("ven").checked),new Boolean(document.getElementById("sam").checked),new Boolean(document.getElementById("dim").checked)];
    for (let i=0; i<7;i++) { 
        if (check1[i]==true) {
            jours = jours +  semaine[i];
        }
    }

    var check2 = [new Boolean(document.getElementById("8-10").checked),new Boolean(document.getElementById("10-12").checked),new Boolean(document.getElementById("12-14").checked),new Boolean(document.getElementById("14-16").checked),new Boolean(document.getElementById("16-18").checked),new Boolean(document.getElementById("18-20").checked)];
    for (let i=0; i<6;i++) { 
        if (check2[i]==true) {
            horaires = horaires +  creneaux[i];
        }
    }
    localStorage.setItem('jours', jours);
    localStorage.setItem('horaires', horaires);
    
}

function test2 (form){
    specialite=" ";
    nom_medecin=" ";
    adresse=" ";
    code_postal=" ";
    ville=" ";
    pays=" ";
    perimetre=" ";
    localStorage.setItem('specialite', specialite);
    localStorage.setItem('nom_medecin', nom_medecin);
    localStorage.setItem('adresse', adresse);
    localStorage.setItem('code_postal', code_postal);
    localStorage.setItem('ville', ville);
    localStorage.setItem('pays', pays);
    localStorage.setItem('perimetre', perimetre);
}



